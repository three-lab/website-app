<?php

namespace System\Exceptions;

use Exception;

class QueryException extends Exception
{

}
