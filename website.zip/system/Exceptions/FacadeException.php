<?php

namespace System\Exceptions;

use Exception;

class FacadeException extends Exception
{

}
