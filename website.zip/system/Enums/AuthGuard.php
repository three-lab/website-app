<?php

namespace System\Enums;

enum AuthGuard: string
{
    case WEB = 'web';
    case API = 'api';
}
