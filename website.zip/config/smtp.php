<?php

return [
    'host' => env('SMTP_HOST'),
    'username' => env('SMTP_USER'),
    'password' => env('SMTP_PASS'),
    'port' => env('SMTP_PORT'),
    'from_mail' => env('SMTP_FROM'),
];
