<?php

return [
    'cookie_samesite' => 'Strict',
    'cookie_secure' => true,
];
